# Purpose of This Repo

This repo is used to provide access to files for exercises as part of the Introduction to Machine Learning course,, ND 189, course #1


