# Exercise: Supervised and Unsupervised Machine Learning

Using the iris dataset from the previous lesson, we're going to create two models, one supervised, one unsupervised, and compare how their predictions differ.

Complete the notebook by filling in the code where there are `?`.
